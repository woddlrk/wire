document.querySelector('button').addEventListener('click',function(){
    document.querySelector('.popup').style.display='none';
})